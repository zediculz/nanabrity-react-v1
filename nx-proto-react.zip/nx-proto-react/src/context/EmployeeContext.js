import React, { createContext, useState, useEffect } from 'react'
import axios from 'axios'


export const EmployeeContext = createContext()

const EmployeeContextProvider = ({ children }) => {

    //states
    //btc amount and the conversion in naira
    const [btcAmount, setBtcAmount] = useState(0)
    const [nairaAmount, setNairaAmount] = useState(0)

    //trade order ID
    const [tradeId, setTradeId] = useState('')
    const [tradeType, setTradeType] = useState('')

    //date and status
    const [date, setDate] = useState(null)
    const [status, setStatus] = useState('')

    //recepient amount
    const [name, setName] = useState('')
    const [account, setAcct] = useState('')
    const [bank, setBank] = useState(0)
    const [email, setEmail] = useState('')


    //context methods
    //set trade amount and the conversion amount
    const setAmount = (e) => setBtcAmount(e)
    const setConvert = (e) => setNairaAmount(e)


    //method that set trade id
    const setId = (e) => setTradeId(e)
    const setType = (e) => setTradeType(e)

    //set recepient details
    const setDName = (name) => setName(name)
    const setDAcct = (acct) => setAcct(acct)
    const setDBank = (bank) => setBank(bank)
    const setDEmail = (email) => setEmail(email)

    let today = new Date();
    let d = `${today.getFullYear()}-${today.getMonth()}-${today.getDate()}`;
    let t = `${today.getHours()}:${today.getMinutes()}`;
    let datec = `${d} ${t}`;

    //rate and address
    const [ar, setAR] = useState({})
    const tradeRateandAddr = (data) => setAR(data)

    //generating current date
    const generateDate = () => {
        setStatus("ORDER CONFIRMED")
    }

    const storeTrade = () => {
        const trans = `https://howtothese.xyz/snappy/api/v1/trans/trans.php?name=${name}&email=${email}&account=${account}&bankname=${bank}&amount=${btcAmount}&cAmt=${nairaAmount}&tradeId=${tradeId}&status=${status}&image=${''}&type=${tradeType}&date=${datec}`;
        axios.get(trans).then(res => {
           
            /*
            if (res.data.status === 200) {
                return true
            } else {
                return false
            } */
        })
    }

    return (
        <EmployeeContext.Provider
            value={{ btcAmount, setAmount, tradeId, setId, setType, setDName, setDAcct, name, account, bank, email, setConvert, nairaAmount, setDBank, setDEmail, tradeType, tradeRateandAddr, ar, date, status, generateDate, storeTrade}}>
            {children}
        </EmployeeContext.Provider>
    )
}

export default EmployeeContextProvider