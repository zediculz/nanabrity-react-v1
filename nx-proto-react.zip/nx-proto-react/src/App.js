import React from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom'


//routes
import Home from './routes/home'
import Send from './routes/Send';
import Receive from './routes/Receive';
import Order from './routes/order'
import Service from './routes/Service';
import Payment from './routes/Payment'

//context
import EmployeeContextProvider from './context/EmployeeContext'
import Header from './layouts/Header';

function App() {
  return (
    <EmployeeContextProvider>
      <BrowserRouter>
        <div className='main'>
          <Switch>
            <Route path="/" exact component={Home}></Route>
            <Route path="/send" exact component={Send}></Route>
            <Route path="/receive" exact component={Receive}></Route>
            <Route path="/order" exact component={Order}></Route>
            <Route path="/send/:country/:acct/:code" exact component={Service}></Route>
            <Route path="/payment/:country/:userkey/:amt" exact component={Payment}></Route>
            <Route path="" component={error}></Route>
          </Switch>
        </div>
      </BrowserRouter>
    </EmployeeContextProvider>
  )
}


const error = () => {
  return (
    <div>
      <Header />
      <div style={style.home}>
        <h1>404</h1>
        <p>SEEMS THERES NETWORK ISSUE OR THE PAGE DON'T EXIST</p>
      </div>
    </div>
  
  )
}





const style = {
  home: {
    background: 'white',
    width: '100%',
    height: '90vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'lightslategrey',
    flexDirection: 'column'
  }
}
 
export default App;