import React, { useEffect, useState } from "react";
import axios from "axios";
import { useHistory } from "react-router-dom";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";
import copy from "copy-to-clipboard";

//approve image
import approved from '../approved.png'

const Payment = (params) => {
    //states
    const [alert, setAlert] = useState("");
    const [submitted, setSubmitted] = useState(false);
    const [Completed, setCompleted] = useState(false);
    const [success, setSuccess] = useState(false)

    const [email, setEmail] = useState("");
    const [amount, setAmount] = useState("");
    const [btcamount, setBtcAmount] = useState("");
    const [namount, setNamount] = useState()

    //pre-states
    const [acct, setAcct] = useState("");
    const [bankcode, setBankCode] = useState("");
    const [country, setCountry] = useState("");
    const [acctname, setAcctName] = useState("");
    const [bankName, setBankName] = useState("");

    //rate and addr
    const [rate, setRate] = useState(0);
    const [addr, setAddr] = useState("");
    const [bnRate, setBnRate] = useState("");
    const [lAlert, setLalert] = useState("Copy Address");

    //trade id 
    const [tradeId, setTradeId] = useState(0)

    const history = useHistory();

    const loadPreStates = (acct, country, code) => {
        let myHeaders = new Headers();
        myHeaders.append(
            "Authorization",
            "Bearer sk_live_33940cd2e36af1c3945db0255928798992b741c5"
        );

        let requestOptions = {
            method: "GET",
            headers: myHeaders,
            redirect: "follow",
        };

        fetch(
            `https://api.paystack.co/bank/resolve?account_number=${acct}&bank_code=${code}`,
            requestOptions
        )
            .then((res) => res.json())
            .then((result) => {
                if (result.status) {
                    setAcct(result.data.account_number);
                    setAcctName(result.data.account_name);
                    setCountry(country);
                    setBankCode(code);
                    loadBankName(code);
                } else {
                    history.push("/");
                }
            });
    };

    const loadBankName = (code) => {
        fetch("https://api.paystack.co/bank")
            .then((res) => res.json())
            .then((data) => {
                data.data.map((bank) => {
                    if (code === bank.code) {
                        setBankName(bank.name);
                    }
                });
            });
    };

    const amtToSat = (amt) => {
        axios
            .get(`https://blockchain.info/tobtc?currency=USD&value=${amt}`)
            .then((data) => setBtcAmount(data.data));
    };

    const btcNgnRate = () => {
        axios.get(`https://blockchain.info/ticker`).then((data) => {
            setBnRate(data.data.USD.buy);
        });
    };

    const loadQR = () => {
        axios.get(`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${addr}`).then(data => console.log(data))
    }


    const loadRateandAddr = () => {
        fetch("https://howtothese.xyz/snappy/api/v1/trans/rates.php")
            .then((res) => res.json())
            .then((data) => {
                const { one, address } = data.data;
                btcNgnRate();
                setRate(Number(one));
                setAddr(address);
                setTradeId(`NA${Math.floor(Math.random() * 99999)}`)
            });
    };

    //copy link
    const copyToClip = (e) => {
        //const copyAddr = e.currentTarget.innerHTML
        copy(e);
        setLalert("Address Copied");
        TELEGRAMALERTCOPY()

    };



    //complete trade
    const handleCompleteTrade = () => {
        setTimeout(() => {
            //store trade details to db
            //load /successfully
            //and / home button
            setCompleted(false)
            setSuccess(true)
            storeTrade()
        }, 2400)
    }

    //store trade
    const storeTrade = () => {
        let today = new Date();
        let d = `${today.getFullYear()}-${today.getMonth()}-${today.getDate()}`;
        let t = `${today.getHours()}:${today.getMinutes()}`;
        let datec = `${d} ${t}`;

        const trans = `https://howtothese.xyz/snappy/api/v1/trans/trans.php?name=${acctname}&email=${email}&account=${acct}&bankname=${bankName}&amount=${amount}&cAmt=${namount}&tradeId=${tradeId}&status=${'ORDER CONFIRMED'}&type=${country}&date=${datec}`;
        axios.get(trans).then(res => {


            if (res.status === 200) {
                TELEGRAMALERTCOMPLETED()
            }
        })
    }


    useEffect(() => {
        loadRateandAddr();
        console.log('payment')
        const { acct, country, code, userkey } = params.match.params;
        console.log(params.match.params)
        loadPreStates(acct, country, code);
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();

        if (amount === "" || amount < 20) {
            setAlert("Minimium Amount is $20");
            setTimeout(() => setAlert(""), 2000);
        } else {
            if (amount > 1500) {
                setAlert("Maximium Amount is $1500");
                setTimeout(() => setAlert(""), 2000);
            } else {
                if (email === "") {
                    setAlert("Email can't be Empty");
                    setTimeout(() => setAlert(""), 2000);
                } else {
                    setTimeout(() => {
                        amtToSat(amount);
                        gg(amount)
                        setTimeout(() => {
                            setSubmitted(true);
                            setCompleted(true)
                        }, 400)
                    }, 800);
                }
            }
        }
    };

    const gg = (e) => {

        if (e >= 20 && e <= 200) {
            setNamount((rate - 14) * amount)
            TELEGRAMALERTSTART(namount)


        } else if (e > 200 && e <= 800) {
            setNamount((rate - 7) * amount)
            TELEGRAMALERTSTART(namount)


        } else if (e > 800) {
            setNamount(rate * amount)
            TELEGRAMALERTSTART(namount)


        }



    }


    //first notification
    const TELEGRAMALERTSTART = () => {
        const text = `
              New Trade started with 
                    trade Id: ${tradeId}
                         name: ${acctname}
                    amount: ${amount}
                                  bank: ${acct} | ${bankName}`


        const id = -409768100
        const url = `https://api.telegram.org/bot1395333672:AAGCdmjZaIQZyHPiwz2iLlmYHFspIbze3ik/sendMessage?chat_id=${id}&text=${text}`
        axios.post(url)
    }

    //second notification
    const TELEGRAMALERTCOMPLETED = () => {
        const text = `completed`

        const id = -409768100
        const url = `https://api.telegram.org/bot1395333672:AAGCdmjZaIQZyHPiwz2iLlmYHFspIbze3ik/sendMessage?chat_id=${id}&text=${text}`
        axios.post(url)
    }

    //third notification
    const TELEGRAMALERTCOPY = () => {
        const text = `New Trade started with 
                     trade Id: ${tradeId} Proceeded Please check
                           amount: ${namount}`

        const id = -409768100
        const url = `https://api.telegram.org/bot1395333672:AAGCdmjZaIQZyHPiwz2iLlmYHFspIbze3ik/sendMessage?chat_id=${id}&text=${text}`
        axios.post(url)
    }

    return (
        <div>
            <Header />
            <div className="wrapper">

                <div className="service-inst">
                    <h3>{acctname}</h3>
                    <p>
                        {submitted
                            ? "Transaction Details"
                            : "Enter Amount between 20 and 1500 USD"}
                    </p>
                </div>
                <div style={{ display: submitted ? "none" : "block" }} className="service-alert-wrap"><p>{alert}</p> </div>
                <div style={{ display: submitted ? "none" : "block" }} className="service-card">
                    <form onSubmit={handleSubmit}>
                        <div>
                            <label>Amount</label>
                            <input
                                type="number"
                                placeholder="$20"
                                onChange={(e) => setAmount(e.target.value)}
                            />
                        </div>
                        <div>
                            <label>Provide a valid Email for Payment Notifcation</label>
                            <input
                                type="email"
                                placeholder="xxx@email.com"
                                onChange={(e) => setEmail(e.target.value)}
                            />
                        </div>

                        <div className="btn-wrap">
                            <button type="submit">Send</button>
                        </div>
                    </form>
                </div>

                <div className="service" style={{ display: Completed ? "block" : "none" }} >
                    <div className="review-services">
                        <p>Account Number<span className="pre">{submitted ? acct : ""} | {bankName}</span>
                        </p>

                        <p>
                            Sending<span className="pre">{btcamount} BTC @ {bnRate}</span>
                        </p>
                        <p>
                            Receiving<span className="pre">{namount} Naira</span>
                        </p>
                    </div>
                    <div className="ins-services">
                        <div className="qr-box">
                            <img src={`https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${addr}`} alt="qr" />
                        </div>

                        <div className="ins-box">
                            <h4>How to Complete Payment</h4>
                            <p>
                                Copy the Crypto Address provided into your wallet & Send Exact
                                Amount of bitcoin.
                </p>
                            <p>
                                click "Completed" and wait as recipient  will receive the naira value in minutes.
                </p>
                        </div>
                    </div>

                    <div className="cta-services">
                        <div>
                            <button onClick={() => copyToClip(addr)}>
                                {lAlert}
                            </button>
                            <button onClick={handleCompleteTrade}>Completed</button>
                        </div>
                    </div>
                </div>
                <div className="done" style={{ display: success ? "block" : "none" }}>
                    <div className="done-img">
                        <img src={approved} alt='approved transaction' />
                    </div>
                    <div className="done-text">
                        <p>trade with ID: {tradeId} confirmed, as {acctname} will receive the naira value in minutes, Thank You.</p>
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default Payment;