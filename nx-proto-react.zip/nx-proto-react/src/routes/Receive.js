import React, { useState, useEffect } from 'react'

//click copy module
import copy from "copy-to-clipboard"; 

//layout component
import Header from '../layouts/Header'
import Footer from '../layouts/Footer'

//main
const Receive = () => {
   
    //error handler
    const [alert, setAlert] = useState('')

    //account details
    const [acct, setAcct] = useState('')
    const [bankcode, setBankCode] = useState('')
    const [country, setCountry] = useState("");
    const [acctname, setAcctName] = useState("");
    const [link, setLink] = useState('')
    const [generated, setGen] = useState(false)


    //load banklist
    //bank code
    //aacount number
    //validate account number
    const [bankDetails, setBankDetails] = useState([])

    //click to copy link function
    const copyToClip = (e) => {
        //const copyAddr = e.currentTarget.innerHTML
        copy(e)
    }



    //load all bank list from paystack
    useEffect(() => {
        fetch('https://api.paystack.co/bank')
            .then(res => res.json()).then(data => {
                setBankDetails(data.data)
            })
    }, [])


    //first submit
    const startTrade = e => {
        e.preventDefault()
        if (acct === '') {
            setAlert('Please Provide a Valid Account')
            setTimeout(() => setAlert(''), 2000)
        } else {
            let myHeaders = new Headers();
            myHeaders.append("Authorization", "Bearer sk_live_33940cd2e36af1c3945db0255928798992b741c5");

            let requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };

            setAlert('Validation Please Wait')

            //validation account number using paystack
            fetch(`https://api.paystack.co/bank/resolve?account_number=${acct}&bank_code=${bankcode}`, requestOptions)
                .then(res => res.json()).then(result => {
                    if (result.status) {
                        setAcctName(result.data.account_name)
                        setLink(`https:nanabrity.com/send/${country}/${acct}/${bankcode}`)
                        setGen(true)
                        setAlert('Copy Link Below')
                    } else {
                        setAlert('Please Provide a Valid Account')
                        setTimeout(() => setAlert(''), 3400)
                    }
                })
        }

    }


    //second submit to copy the generated link
    const linkCopied = e => {
        e.preventDefault()
        setLink(`https:nanabrity.com/send/${country}/${acct}/${bankcode}`)
        setGen(true)
        copyToClip(link)
        setAlert('Link Copied Successfully')
    }

 
    //jsx
    return (
        <div>
            <Header />
            <div className="wrapper">
                <div className="inst">
                    <h3>Receive Money</h3>
                    <p>receive BTC with a valid bank account</p>
                </div>
                <div className="alert-wrap">
                    <span>{alert}</span>
                </div>
                <div className='card-wrap'>
                    <form onSubmit={startTrade}>
                        <div>
                            <label>Country</label>
                            <select onChange={e => setCountry(e.target.value)}>
                                <option value=" "></option>
                                <option value="ng">Nigeria</option>
                            </select>
                        </div>
                        <div>
                            <label>Bank</label>
                            <select onChange={e => setBankCode(e.target.value)}>
                                {bankDetails.map(bank => (
                                    <option key={bank.code} value={bank.code}>{bank.name}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label>Account Number</label>
                            <input
                                type="number" placeholder="XXX" onChange={e => setAcct(e.target.value)}
                            />
                        </div>

                        <div className="btn-wrap">
                            <button type="submit" style={{display: generated ? 'none' : 'block'}}>Receive</button>
                            <button type="button" style={{ display: generated ? 'block' : 'none' }} onClick={linkCopied}>Copy Link</button>
                        </div>
                    </form>
                </div>

            </div>
            <Footer />
        </div>
    )
}


export default Receive