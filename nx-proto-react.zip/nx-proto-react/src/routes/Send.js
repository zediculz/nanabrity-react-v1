import React, { useContext, useState, useEffect} from 'react'
import { EmployeeContext } from '../context/EmployeeContext'
import { useHistory } from 'react-router-dom'

import Header from '../layouts/Header'
import Footer from '../layouts/Footer'

const Send = () => {
    const { setAmount, setConvert, setType, ar, setDEmail, tradeType} = useContext(EmployeeContext) 
    const history = useHistory()

    //error handler
    const [alert, setAlert] = useState('')
    const [acct, setAcct] = useState('')
    const [bankcode, setBankCode] = useState('')
    const [country, setCountry] = useState("");
    const [acctname, setAcctName] = useState("");


    //load banklist
    //bank code
    //aacount number
    //validate account number

    const [bankDetails, setBankDetails] = useState([])


    useEffect(() => {
        fetch('https://api.paystack.co/bank')
            .then(res => res.json()).then(data => {
                setBankDetails(data.data)
            })
    }, [])


    //form handler
    const startTrade = e => {
        e.preventDefault()
        if (acct === '') {
            setAlert('Please Provide a Valid Account')
            setTimeout(() => setAlert(''), 2000)
        } else {
            let myHeaders = new Headers();
            myHeaders.append("Authorization", "Bearer sk_live_33940cd2e36af1c3945db0255928798992b741c5");

            let requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };

            setAlert('Validation Please Wait')

            fetch(`https://api.paystack.co/bank/resolve?account_number=${acct}&bank_code=${bankcode}`, requestOptions)
                .then(res => res.json()).then(result => {
                    if (result.status) {
                        setAcctName(result.data.account_name)
                        setAlert(result.data.account_name)
                        history.push(`/send/${country}/${acct}/${bankcode}`)
                    } else {
                        setAlert('Please Provide a Valid Account')
                        setTimeout(() => setAlert(''), 2000)
                }
            })
        }
       
    }

    return (
        <div>
            <Header />
            <div className="wrapper">
                <div className="inst">
                    <h3>Send Money</h3>
                    <p>provide a valid account</p>
                </div>
                <div className="alert-wrap">
                    <span>{alert}</span>
                </div>
                <div className='card-wrap'>
                    <form onSubmit={startTrade}>
                        <div>
                            <label>Country</label>
                            <select onChange={e => setCountry(e.target.value)}>
                                <option value=" "></option>
                                <option value="ng">Nigeria</option>
                            </select>
                        </div>
                        <div>
                            <label>Bank</label>
                            <select onChange={e => setBankCode(e.target.value)}>
                                {bankDetails.map(bank => (
                                    <option key={bank.code} value={bank.code}>{bank.name}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label>Account Number</label>
                            <input
                                type="number" placeholder="XXX" onChange={e => setAcct(e.target.value)}
                            />
                        </div>

                        <div className="btn-wrap">
                            <button type="submit">Continue</button>
                        </div>
                    </form>
                </div>
               
            </div>
            <Footer />
        </div>
    )
}


export default Send