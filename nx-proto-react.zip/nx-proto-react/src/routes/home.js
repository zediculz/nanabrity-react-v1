import React from "react";
import { useHistory } from "react-router-dom";

//component
import Hiw from "../components/hiw";
import Why from "../components/why";
import Faq from '../components/faq'
import Cta from '../components/cta'
import Showcase from '../components/showcase'

import Header from '../layouts/Header'
import Footer from '../layouts/Footer'


const Home = () => {
  const history = useHistory();

    //starting each trade
    const handleSend = () => history.push("/send");
    const handleReceive = () => history.push("/receive");

  return (
    <section>
      <Header />
      <Showcase sendBtn={handleSend} receiveBtn={handleReceive}  />
      <Hiw />
      <Cta msg={'Send Money To friends and family using Bitcoin'} />
      <Why />
      <Cta msg={'Exchange your bitcoin to naira using only your account'} />
      <Faq />
      <Footer />
    </section>
  );
};

export default Home;