import React, { useState } from 'react'
import { useHistory } from 'react-router-dom'

import Header from '../layouts/Header'

const Order = () => {
    const history = useHistory()

    //error handler
    const [alert, setAlert] = useState('')
    const [inputId, setInput] = useState('')

    //form handler
    const startTrade = e => {
        e.preventDefault()

        if (inputId === '') {
            setAlert("Fields Can't be Empty");
            setTimeout(() => setAlert(""), 2000);
        } else {
            setInput('')
            history.push(`/orderdetails/${inputId}`)
        }
    }

    return (
        <div className="wrapper">
            <Header />
            <div className="inst">
                <h3>Track your Order</h3>
            </div>
            <div className='card card-one'>
                <form onSubmit={startTrade}>
                    <div className="r-wrap">
                        <p className="o-alert">{alert}</p>
                    </div>
                    <div>
                        <input type="text" onChange={e => setInput(e.target.value)} placeholder='Trade ID' />
                    </div>
                    <div className="btn-wrap">
                        <button type="submit">Track</button>
                    </div>
                </form>
            </div>
        </div>
    )
}


export default Order