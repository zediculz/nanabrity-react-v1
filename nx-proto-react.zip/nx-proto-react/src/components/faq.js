import React from "react";

const Faq = () => {
  return (
    <div className="section-wrap">
      <div className="section">
        <div className="ads">
          <h2>$1000 Limit</h2>
          <p>CBN anti-money laundering policies</p>
        </div>
        <div className="title">
          <h2>FAQ's</h2>
          <p>
            {""}
          </p>
        </div>
        <div className="content faq-content">
          <div className="box">
            <h2>Why $1000 Limit ?</h2>
            <p>
              Acting in accordance with the CBN anti-money laundering policies,
              we limit each transaction to $1000 daily.
            </p>
          </div>
          <div className="box">
            <h2>How can I contact customer services ?</h2>
            <p>
              Our customer services is open 24/7 for your support and enquiries,
              you can email our support{" "}
              <a href="mailto:nanaxchange@gmail.com">nanaxchange@gmail.com</a>
            </p>
          </div>
          <div className="box">
            <h2>What do i need to send/receive money</h2>
            <p>
              a valid account number and Crypto payment can be make using any
              crypto currency wallet of your choice.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Faq;
