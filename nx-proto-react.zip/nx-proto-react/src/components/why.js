import React from 'react'

const Why = props => {
    return (
        <div className='section-wrap'>
            <div className="section">
                <div className="ads">
                    <h2>exchange your bitcoin to naira</h2>
                    <p>Nanabrity is fast and secure</p>
                </div>
                <div className="title">
                    <h2>why Us</h2>
                    <p>in summary, nanabrity exchange is</p>
                </div>
                <div className="content">
                    <div className="box">
                        <h2>Simple</h2>
                        <p>sending Money to Nigeria using bitcoin is as simple as sending bitcoin from your favorite wallets.</p>
                    </div>
                    <div className="box">
                        <h2>Fast</h2>
                        <p>Transactions takes no time as its delivered within or less than 20 Minutes.</p>
                    </div>
                    <div className="box">
                        <h2>Secure</h2>
                        <p>we always ensure 100% customer/transactions security</p>
                    </div>
                </div>
            </div>
       </div>
    )
}

export default Why