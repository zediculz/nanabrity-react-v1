import React, { useContext, useEffect, useState } from 'react'
import axios from 'axios'
import { EmployeeContext } from '../context/EmployeeContext'


const Showcase = props => {
    const { sendBtn, receiveBtn } = props 
    const { tradeRateandAddr } = useContext(EmployeeContext);
    const [bnRate, setBnRate] = useState('')

    const btcNgnRate = () => {
        axios.get(`https://blockchain.info/ticker`).then(data => {
            setBnRate(data.data.USD.buy)
        })
    }

   
    useEffect(() => {
        axios.get('https://howtothese.xyz/snappy/api/v1/trans/rates.php')
            .then(res => {
                if (res.data.status === 200) {
                    tradeRateandAddr(res.data.data)
                    btcNgnRate()
            }
        })
    }, [])

    
    return (
        <section className="showcase">
            <div className="center">
                <div className="word">
                    <h1> Fast and secure cash transfer to nigeria</h1>
                    <p>Using blockchain, cash app, paxful  and other bitcoin wallets</p>
               </div>
                <div className="cta-container">
                    <button onClick={sendBtn}>Send Money</button>
                    <button onClick={receiveBtn}>Receive Money</button>
                </div>
            </div>
            <div className="below-center">
                <h3>BTC/USDT: ${bnRate}</h3>
            </div>
        </section>
    )
}

export default Showcase