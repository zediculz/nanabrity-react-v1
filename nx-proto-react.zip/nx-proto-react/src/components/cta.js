import React from 'react'

const Cta = props => {
    return <div className="cta-wrap"> 
        <h3 style={style.text}>{props.msg}</h3>
    </div>
}

const style = {
    text: {
        color: 'white',
        padding: '4px'
    }
}

export default Cta