import React from 'react'
import img from '../done.png'


const Hiw = props => {
    return (
        <div className='section-wrap'>
            <div className="section">
                <div className="ads">
                    <h2>Explore a better way to send/receive money</h2>
                      <p>in Nigeria using Bitcoin</p>
                </div>
                <div className="title">
                    <h2>How Nanabrity Works</h2>
                    <p>send/receive money in three clicks</p>
                </div>
                <div className="content">
                    <div className="box">
                        <h2>calculate exchange rate</h2>
                        <p>Input the amount of BTC you are transferring in USD and our real-time exchange rate calculate the equal amount in Naira NGN.</p>
                    </div>
                    <div className="box">
                     
                        <h2>Get wallet address</h2>
                        <p>Fill-in correct account details and email address of the recipient to generate a unique BTC Address for the transaction</p>
                    </div>
                    <div className="box">
                       
                        <h2>Pay Crypto</h2>
                        <p>Transfer bitcoin to the wallet address provided and Recipient will automatically receive the naira value in minutes.</p>
                    </div>
                </div>
            </div>
       </div>
    )
}

export default Hiw