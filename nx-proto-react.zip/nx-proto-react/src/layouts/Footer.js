import React from 'react'
import { Link } from 'react-router-dom/cjs/react-router-dom.min';

let today = new Date();
let date = `${today.getFullYear()}`

const Footer = props => {
    return <footer>
        <div>
            <h3>Nanabrity</h3>
            <p>nanabrity@gmail.com</p>
            <p>08107409740</p>
            <p>Mon-Fri (9:00am - 10:00pm)</p>
            <p>{''}</p>
          
            <p className='copyright'>© Copyright {date}, All Rights Reserved</p>
        </div>

    </footer>
}

export default Footer


//  <Link to='/order'>Track Transaction</Link>